API_KEY = 'YOU_API_KEY_HERE'
BASE_URL = 'https://api.tokapi.online'
